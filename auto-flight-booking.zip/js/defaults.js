var DEFAULTS = {
	minPrice: 500000,
	reloadSecond: 10,
	ring: 1
};